
DESCRIPTION
----------------
UEditor(百度编辑器) is Baidu web front-end R & D department developed
WYSIWYG rich text web editor, with a lightweight, customizable,
and focus on user experience and other characteristics,
the open source BSD license, allowing free use and modify the code.

I have used many editors, but ultimately I think UEditor is the 
best, so I want more people to know and use it.

if you have any question about this module, please create a 
issue and let me know, I will always always always ...keep 
actively maintained, enjoy!

Demo: http://ueditor.baidu.com/website/onlinedemo.html
The demo is chinese, You can use the English version on your download.

Installation
-------------
1. Download the ueditor in
http://ueditor.baidu.com/website/index.html.
2. Unzip it into sites/all/libraries,
so that there's like sites/all/libraries/ueditor/ueditor.all.js.
3. Do like this https://drupal.org/node/2286333
4. Enabled ueditor module.
5. Go to admin/people/permissions and grant permission to any roles that need to be 
able to upload file with ueditor.
6. Configure the module at admin/config/content/wysiwyg (You must save at least
once, so that the editor is initialized, otherwise, the editor does not appear)
7. Configure the module at admin/config/content/ueditor (Optional)

Known Issues
-----------------
https://drupal.org/node/2286333
https://drupal.org/node/2286537

Tips: The official website of the Chinese,
You can use the google translation, the operation so easy.
